<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'reset' => 'تم إعادة تعيين كلمة المرور الخاصة بك!',
    'sent' => 'لقد أرسلنا رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني!',
    'throttled' => 'الرجاء الانتظار قبل إعادة المحاولة.',
    'token' => 'رمز إعادة تعيين كلمة المرور هذا غير صالح.',
    'user' => "لا يمكننا العثور على مستخدم بهذا العنوان البريدي.",

    //new keys
    'passowrd_does_not_match' => 'كلمة المرور الحالية لا تتطابق مع كلمة المرور القديمة.',
    'incorrect_password' => 'كلمة مرور غير صحيحة!',
];
