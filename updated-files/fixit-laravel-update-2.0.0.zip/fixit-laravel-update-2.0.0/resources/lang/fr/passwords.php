<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'reset' => 'Votre mot de passe a été réinitialisé !',
    'sent' => 'Nous avons envoyé par e-mail votre lien de réinitialisation de mot de passe !',
    'throttled' => 'Veuillez patienter avant de réessayer.',
    'token' => 'Ce jeton de réinitialisation de mot de passe est invalide.',
    'user' => "Nous ne trouvons pas d'utilisateur avec cette adresse e-mail.",

    //new keys
    'passowrd_does_not_match' => 'Le mot de passe actuel ne correspond pas à l\'ancien mot de passe.',
    'incorrect_password' => 'Mot de passe incorrect !',
];
